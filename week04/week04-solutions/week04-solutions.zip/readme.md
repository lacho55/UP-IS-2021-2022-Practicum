Solutions for week04's tasks.
